"""Generate an offline, interactive and privacy-minimised HTML dashboard."""
from __future__ import annotations
import json
from pathlib import Path
from plotly.offline import get_plotlyjs


def export_dashboard(df,path,source_label):
    # Intentionally exclude customer names, customer IDs, addresses and product titles.
    slim=df[['Order Month','Year','Region','Segment','Category','Sub-Category','Sales','Profit','Discount']].copy()
    payload=slim.to_json(orient='records',double_precision=6)
    payload=payload.replace('</','<\\/')
    label=json.dumps(source_label)
    # Inline plotly assets make the HTML work without network connectivity.
    page='''<!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Superstore | Sales and Profitability</title>
    <style>
     :root{font-family:Inter,Segoe UI,Arial,sans-serif;color:#172638;background:#f3f6f9}
     body{max-width:1350px;margin:0 auto;padding:30px 22px}
     h1{margin:0 0 7px;font-size:28px} p{color:#64748b;margin:5px 0 22px}
     .hint{padding:12px 14px;background:#fff;border-left:4px solid #5e87a5;border-radius:6px;font-size:13px}
     .filters{display:flex;gap:14px;flex-wrap:wrap;margin:24px 0 18px}
     label{display:flex;flex-direction:column;font-size:12px;gap:7px;color:#4f5f71;font-weight:700}
     select{padding:9px 14px;min-width:160px;background:white;border:1px solid #d6dfe8;border-radius:7px}
     .kpis{display:grid;grid-template-columns:repeat(4,minmax(140px,1fr));gap:14px;margin-bottom:17px}
     .kpi,.chart{background:white;border:1px solid #e1e8ee;border-radius:12px;padding:17px}
     .kpi small{color:#64748b}.kpi strong{display:block;font-size:25px;margin-top:9px}
     .charts{display:grid;grid-template-columns:1fr 1fr;gap:17px}
     .chart{min-height:370px} .wide{grid-column:1/-1}
     @media(max-width:850px){.kpis{grid-template-columns:repeat(2,1fr)}.charts{grid-template-columns:1fr}.wide{grid-column:auto}}
    </style></head><body>
    <h1>Sales Performance and Growth Opportunities</h1>
    <p>Interactive business intelligence | Sales, profitability, discounting, regions and categories</p>
    <div class="hint" id="datasource"></div>
    <div class="filters" id="filters"></div>
    <div class="kpis"><div class="kpi"><small>Sales</small><strong id="sales">—</strong></div>
     <div class="kpi"><small>Profit</small><strong id="profit">—</strong></div>
     <div class="kpi"><small>Weighted margin</small><strong id="margin">—</strong></div>
     <div class="kpi"><small>Sales lines</small><strong id="lines">—</strong></div></div>
    <div class="charts"><div class="chart" id="time"></div><div class="chart" id="region"></div>
     <div class="chart" id="category"></div><div class="chart" id="discount"></div>
    </div>
    <script>__PLOTLY__</script>
    <script>
    const records=__RECORDS__; const sourceLabel=__LABEL__;
    document.getElementById('datasource').textContent='Data source: '+sourceLabel+' | No personally identifying customer details are included.';
    const defs=[['Year','Year'],['Region','Region'],['Category','Category'],['Segment','Segment']];
    defs.forEach(([key,name])=>{
      const lab=document.createElement('label');lab.textContent=name;
      const sel=document.createElement('select');sel.id='f'+key;
      const all=document.createElement('option');all.value='';all.textContent='All '+name;sel.appendChild(all);
      [...new Set(records.map(r=>r[key]))].sort().forEach(v=>{const o=document.createElement('option');o.value=String(v);o.textContent=String(v);sel.appendChild(o)});
      sel.addEventListener('change',update);lab.appendChild(sel);document.getElementById('filters').appendChild(lab);
    });
    const currency=v=>'$'+Number(v).toLocaleString('en-US',{maximumFractionDigits:0});
    const layout=(title)=>({title:{text:title,font:{size:16}},margin:{t:55,l:65,r:20,b:75},paper_bgcolor:'white',plot_bgcolor:'white',font:{color:'#334155'},xaxis:{automargin:true},yaxis:{automargin:true}});
    function agg(rows,col){const m=new Map();rows.forEach(r=>{const k=r[col];let s=m.get(k)||{sales:0,profit:0,n:0};s.sales+=r.Sales;s.profit+=r.Profit;s.n+=1;m.set(k,s)});return [...m].sort((a,b)=>String(a[0]).localeCompare(String(b[0])))}
    function update(){
      const x=records.filter(r=>defs.every(([k])=>{let v=document.getElementById('f'+k).value;return !v||String(r[k])===v}));
      const sales=x.reduce((s,r)=>s+r.Sales,0), profit=x.reduce((s,r)=>s+r.Profit,0);
      document.getElementById('sales').textContent=currency(sales);
      document.getElementById('profit').textContent=currency(profit);
      document.getElementById('margin').textContent=sales?(100*profit/sales).toFixed(2)+'%':'—';
      document.getElementById('lines').textContent=x.length.toLocaleString('en-US');
      const t=agg(x,'Order Month');
      Plotly.react('time',[{x:t.map(z=>z[0]),y:t.map(z=>z[1].sales),type:'scatter',mode:'lines+markers',line:{color:'#316e9a'}}],layout('Monthly sales'),{responsive:true,displayModeBar:false});
      const r=agg(x,'Region');
      Plotly.react('region',[{x:r.map(z=>z[0]),y:r.map(z=>z[1].profit),type:'bar',marker:{color:r.map(z=>z[1].profit<0?'#a34f49':'#527e9c')}}],layout('Profit by region'),{responsive:true,displayModeBar:false});
      const c=agg(x,'Category');
      Plotly.react('category',[{x:c.map(z=>z[0]),y:c.map(z=>z[1].sales),name:'Sales',type:'bar',marker:{color:'#7da3bc'}},{x:c.map(z=>z[0]),y:c.map(z=>z[1].profit),name:'Profit',type:'bar',marker:{color:'#54a58f'}}],{...layout('Sales and profit by category'),barmode:'group'}, {responsive:true,displayModeBar:false});
      const bands=['None','>0–20%','>20–40%','>40–60%','>60%'];
      const vals=bands.map((_,i)=>x.filter(r=>i===0?r.Discount===0:(i===1?r.Discount>0&&r.Discount<=.2:i===2?r.Discount>.2&&r.Discount<=.4:i===3?r.Discount>.4&&r.Discount<=.6:r.Discount>.6)).reduce((s,r)=>s+r.Profit,0));
      Plotly.react('discount',[{x:bands,y:vals,type:'bar',marker:{color:vals.map(v=>v<0?'#b9605d':'#498fa5')}}],layout('Total profit by discount band'),{responsive:true,displayModeBar:false});
    }
    update();
    </script></body></html>'''
    page=page.replace('__PLOTLY__',get_plotlyjs()).replace('__RECORDS__',payload).replace('__LABEL__',label)
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(page,encoding='utf-8')
    return path
