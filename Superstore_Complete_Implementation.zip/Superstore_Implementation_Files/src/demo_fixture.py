"""Synthetic fixture solely for software testing. Not research evidence of actual retail outcomes."""
import numpy as np
import pandas as pd
from pathlib import Path


def generate_demo(path,seed=19,n=760):
    rng=np.random.default_rng(seed)
    regions=['West','East','Central','South']
    categories={'Furniture':['Bookcases','Chairs','Tables'],
                'Technology':['Phones','Accessories','Machines'],
                'Office Supplies':['Paper','Binders','Storage']}
    rows=[]
    for i in range(n):
        if i % 2 == 0:
            dt=pd.Timestamp('2014-01-01')+pd.Timedelta(days=int(rng.integers(0,1460)))
            order_customer=f'CUS-{int(rng.integers(1,91)):03d}'
            order_region=str(rng.choice(regions))
            order_segment=str(rng.choice(['Consumer','Corporate','Home Office']))
            order_shipping_days=int(rng.integers(1,7))
        cat=rng.choice(list(categories));sub=rng.choice(categories[cat]);region=order_region
        discount=float(rng.choice([0,.1,.2,.3,.4,.6],p=[.25,.20,.25,.12,.12,.06]))
        qty=int(rng.integers(1,10));sales=float(np.round(max(.01,rng.normal(75,24)*qty*(1-discount)),2))
        profit=float(np.round(sales*(.23-1.1*discount+ rng.normal(0,.10)),3))
        customer=order_customer
        rows.append({'Row ID':i+1,'Order ID':f'ORD-{i//2:05d}','Order Date':dt.strftime('%m/%d/%Y'),
           'Ship Date':(dt+pd.Timedelta(days=order_shipping_days)).strftime('%m/%d/%Y'),
           'Ship Mode':str(rng.choice(['Standard Class','Second Class','First Class'])),
           'Customer ID':customer,'Customer Name':'DEMO CUSTOMER',
           'Segment':order_segment,
           'Country':'Synthetic example','City':'Example City','State':'Example State','Postal Code':'00000',
           'Region':region,'Product ID':f'DEMO-{cat[:3]}-{i%30:03d}',
           'Category':cat,'Sub-Category':sub,'Product Name':'SYNTHETIC PRODUCT',
           'Sales':sales,'Quantity':qty,'Discount':discount,'Profit':profit})
    out=Path(path);out.parent.mkdir(exist_ok=True,parents=True)
    pd.DataFrame(rows).to_csv(out,index=False)
    return out
