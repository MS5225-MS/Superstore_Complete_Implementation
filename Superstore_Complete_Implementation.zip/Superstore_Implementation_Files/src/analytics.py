"""Reproducible Superstore analytics. The source dataset is never modified in place."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, silhouette_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestRegressor

REQUIRED = {
    'Row ID','Order ID','Order Date','Ship Date','Customer ID','Segment','Region',
    'Category','Sub-Category','Sales','Quantity','Discount','Profit',
}
GROUPS = ('Region','Category','Sub-Category','Segment')
SEED = 42


def read_clean(path: Path):
    """Load CSV with strict schema checks and preserve valid loss-making sales lines."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Superstore CSV not found: {path}. Obtain the actual file; demo mode is explicitly separate.')
    raw = pd.read_csv(path, encoding='utf-8-sig', low_memory=False)
    if not REQUIRED.issubset(raw.columns):
        raise ValueError(f'Missing required fields: {sorted(REQUIRED-set(raw.columns))}')
    df = raw.copy()
    audit = {'source_file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
             'raw_rows':int(len(raw)), 'raw_columns':int(len(raw.columns)),
             'missing_values_by_field':{k:int(v) for k,v in raw.isna().sum().items() if v},
             'exact_duplicate_rows':int(raw.duplicated().sum()),
             'duplicate_row_id':int(raw['Row ID'].duplicated().sum())}
    if raw['Row ID'].isna().any() or raw['Row ID'].duplicated().any():
        raise ValueError('Row ID must uniquely identify each transaction line.')
    # The common Tableau Superstore CSV uses U.S. month/day/year dates.
    for col in ('Order Date','Ship Date'):
        df[col] = pd.to_datetime(df[col].astype('string'),format='%m/%d/%Y',errors='coerce')
        if df[col].isna().any():
            raise ValueError(f'{col} contains {int(df[col].isna().sum())} null or unparseable dates (expected M/D/YYYY).')
    for col in ('Sales','Quantity','Discount','Profit'):
        df[col] = pd.to_numeric(df[col],errors='coerce')
        if df[col].isna().any() or ~np.isfinite(df[col].values).all():
            raise ValueError(f'{col} must be finite and non-null.')
    for col in ('Order ID','Customer ID','Segment','Region','Category','Sub-Category'):
        if df[col].isna().any() or df[col].astype(str).str.strip().eq('').any():
            raise ValueError(f'{col} contains missing identifiers or categories.')
    if (df['Quantity'] <= 0).any() or (df['Sales'] < 0).any():
        raise ValueError('Sales must be non-negative and Quantity positive for this specific dataset.')
    if ((df['Discount']<0)|(df['Discount']>1)).any():
        raise ValueError('Discount is a fraction, required between 0 and 1 inclusive.')
    if (df['Ship Date'] < df['Order Date']).any():
        raise ValueError('Ship Date precedes Order Date for one or more rows.')
    df['Year']=df['Order Date'].dt.year.astype(int)
    df['Month']=df['Order Date'].dt.month.astype(int)
    df['Order Month']=df['Order Date'].dt.to_period('M').astype(str)
    df['Shipping Days']=(df['Ship Date']-df['Order Date']).dt.days
    df['Margin Pct']=np.where(df['Sales']>0,100*df['Profit']/df['Sales'],np.nan)
    df['Discount Band']=pd.cut(df['Discount'],bins=[-1e-9,0,0.2,0.4,0.6,1],
                labels=['None','>0–20%','>20–40%','>40–60%','>60%'])
    audit.update({'clean_rows':int(len(df)),'dropped_rows':0,
        'order_count':int(df['Order ID'].nunique()),'customer_count':int(df['Customer ID'].nunique()),
        'date_min':str(df['Order Date'].min().date()),'date_max':str(df['Order Date'].max().date()),
        'negative_profit_lines':int((df['Profit']<0).sum()),
        'retained_negative_profit_lines':int((df['Profit']<0).sum()),
        'sales_total':round(float(df['Sales'].sum()),4),
        'profit_total':round(float(df['Profit'].sum()),4),
        'date_parsing':'M/D/YYYY', 'excluded_columns_from_dashboard':['Customer Name','Customer ID','Product Name']})
    return df,audit


def aggregate(df,col):
    out=df.groupby(col,observed=True,dropna=False).agg(
            line_items=('Sales','size'), orders=('Order ID','nunique'),
            sales=('Sales','sum'), profit=('Profit','sum')).reset_index()
    out['margin_pct']=np.where(out['sales']!=0,100*out['profit']/out['sales'],np.nan)
    if not np.isclose(out['sales'].sum(),df['Sales'].sum(),atol=1e-6):
        raise AssertionError(f'Sales not reconciled by {col}')
    if not np.isclose(out['profit'].sum(),df['Profit'].sum(),atol=1e-6):
        raise AssertionError(f'Profit not reconciled by {col}')
    return out.sort_values('sales',ascending=False).reset_index(drop=True)


def monthly_summary(df):
    return df.groupby('Order Month').agg(sales=('Sales','sum'),profit=('Profit','sum'),
                             orders=('Order ID','nunique')).reset_index().sort_values('Order Month')


def customer_segmentation(df):
    latest=df['Order Date'].max()+pd.Timedelta(days=1)
    cust=df.groupby('Customer ID').agg(last_purchase=('Order Date','max'),
         frequency=('Order ID','nunique'),monetary=('Sales','sum'),profit=('Profit','sum')).reset_index()
    cust['recency_days']=(latest-cust['last_purchase']).dt.days
    X=np.column_stack([np.log1p(cust['recency_days']),np.log1p(cust['frequency']),
                       np.log1p(cust['monetary'])])
    model_input=StandardScaler().fit_transform(X)
    candidates=[]
    for k in range(2,min(6,len(cust)-1)+1):
        if len(cust) < 2*k: continue
        model=KMeans(n_clusters=k,random_state=SEED,n_init=10).fit(model_input)
        if len(set(model.labels_))<2 or len(set(model.labels_))>=len(cust):continue
        s=float(silhouette_score(model_input,model.labels_))
        candidates.append((k,s))
    if not candidates:
        cust['cluster']=0
        return cust,{'status':'insufficient_customer_diversity','customers':int(len(cust)),'candidate_scores':[]}
    best=max(candidates,key=lambda x:x[1])[0]
    labels=KMeans(n_clusters=best,random_state=SEED,n_init=10).fit_predict(model_input)
    cust['cluster']=labels
    return cust,{'status':'completed','customers':int(len(cust)),'chosen_k':best,
                 'silhouette':float(dict(candidates)[best]),
                 'candidate_scores':[{'k':int(k),'silhouette':round(s,4)} for k,s in candidates],
                 'cluster_sizes':{str(k):int(v) for k,v in cust['cluster'].value_counts().items()}}


def row_sales_regression(df):
    """Predict transaction sales at checkout using only checkout-visible predictors, not Profit."""
    categorical=['Region','Segment','Category','Sub-Category']
    numerical=['Quantity','Discount','Year','Month']
    order_dates=np.array(sorted(df['Order Date'].unique()))
    if len(order_dates)<10 or len(df)<40:
        return {'status':'insufficient_rows_or_dates'}
    date_cutoff=order_dates[max(1,int(len(order_dates)*0.8))]
    train=df[df['Order Date']<date_cutoff].copy()
    test=df[df['Order Date']>=date_cutoff].copy()
    if len(train)<25 or len(test)<10: return {'status':'insufficient_temporal_split'}
    preprocess=ColumnTransformer([
        ('categories',Pipeline([('imputer',SimpleImputer(strategy='most_frequent')),
            ('encode',OneHotEncoder(handle_unknown='ignore'))]),categorical),
        ('numbers',Pipeline([('imputer',SimpleImputer(strategy='median'))]),numerical)])
    reg=Pipeline([('transform',preprocess),('model',RandomForestRegressor(
        n_estimators=120,min_samples_leaf=3,random_state=SEED,n_jobs=1))])
    reg.fit(train[categorical+numerical],train['Sales'])
    pred=reg.predict(test[categorical+numerical]); naive=np.full(len(test),train['Sales'].mean())
    score=lambda p:{'mae':round(float(mean_absolute_error(test['Sales'],p)),4),
                    'rmse':round(float(np.sqrt(mean_squared_error(test['Sales'],p))),4),
                    'r2':round(float(r2_score(test['Sales'],p)),4)}
    return {'status':'completed','prediction_task':'line-item sales at checkout',
        'train_rows':len(train),'test_rows':len(test),
        'test_start_date':str(pd.Timestamp(date_cutoff).date()),
        'features':categorical+numerical, 'excluded_from_predictors':['Sales','Profit','Margin Pct'],
        'baseline_train_mean':score(naive),'random_forest':score(pred),
        'caveat':'Observational hold-out is not a prospective deployment study.'}


def forecasting_backtest(monthly):
    """Rolling one-step evaluation: prior-month and seasonal-naive versus lagged Ridge."""
    m=monthly.sort_values('Order Month').reset_index(drop=True)
    # Reindex to detect gaps and avoid interpreting a missing month as the previous month.
    idx=pd.period_range(m['Order Month'].iloc[0],m['Order Month'].iloc[-1],freq='M')
    if not idx.astype(str).isin(m['Order Month'].tolist()).all():
        return {'status':'missing_months_check_required'}
    series=m['sales'].values.astype(float)
    n=len(series)
    if n<30:return {'status':'too_few_months','months':n}
    holdout=min(12,max(6,n//4))
    obs=[]
    for t in range(n-holdout,n):
        def lagfeat(i):return [series[i-1],series[i-2],series[i-3],series[i-12]]
        X_train=np.array([lagfeat(i) for i in range(12,t)])
        y_train=np.array([series[i] for i in range(12,t)])
        model=Ridge(alpha=10.0).fit(X_train,y_train)
        obs.append({'month':str(m.loc[t,'Order Month']),'actual':series[t],
            'last_month':series[t-1],'seasonal_naive':series[t-12],
            'ridge':max(0,float(model.predict(np.array([lagfeat(t)]))[0]))})
    result=pd.DataFrame(obs)
    def score(col):return {'mae':round(float(mean_absolute_error(result['actual'],result[col])),4),
             'rmse':round(float(np.sqrt(mean_squared_error(result['actual'],result[col]))),4)}
    return {'status':'completed','months':n,'backtest_months':holdout,
        'holdout_start':result['month'].iloc[0],
        'monthly_last_month':score('last_month'),
        'seasonal_naive':score('seasonal_naive'), 'ridge_lags':score('ridge'),
        'note':'Rolling-origin one-step backtest; Ridge is refit each month and uses past data only.'}


def compute_all(df):
    summaries={k:aggregate(df,k) for k in GROUPS}
    summaries['Discount Band']=aggregate(df,'Discount Band')
    monthly=monthly_summary(df)
    cust,cluster=customer_segmentation(df)
    regression=row_sales_regression(df)
    forecasts=forecasting_backtest(monthly)
    return summaries,monthly,cust,{'clustering':cluster,'regression':regression,'forecasting':forecasts}
