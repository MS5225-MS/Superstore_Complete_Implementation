"""CLI: run on supplied CSV, or explicitly execute demo fixture for software verification."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from src.analytics import read_clean, compute_all
from src.dashboard import export_dashboard
from src.demo_fixture import generate_demo


def run(source,out,demo=False):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    df,audit=read_clean(source)
    if not demo and 'Country' in df.columns and df['Country'].astype(str).eq('Synthetic example').all():
        raise ValueError('This CSV is a synthetic fixture. Use --demo and label the outputs honestly.')
    tables,month,customers,models=compute_all(df)
    for name,t in tables.items():t.to_csv(out/f'summary_{name.lower().replace(" ","_").replace("-","_")}.csv',index=False)
    month.to_csv(out/'monthly_sales.csv',index=False)
    customers.drop(columns=['last_purchase']).to_csv(out/'customer_clusters_internal.csv',index=False)
    df.drop(columns=['Customer Name','Product Name'],errors='ignore').to_csv(out/'cleaned_superstore_internal.csv',index=False)
    for name,table in [('sales_trend',month),('profit_by_region',tables['Region']),('profit_by_category',tables['Category'])]:
        plt.figure(figsize=(10,4.4))
        if name=='sales_trend':plt.plot(table['Order Month'],table['sales'],linewidth=1.4);plt.xticks(rotation=75);plt.ylabel('USD Sales')
        else:plt.bar(table.iloc[:,0].astype(str),table['profit']);plt.ylabel('USD Profit');plt.xticks(rotation=22)
        plt.title(name.replace('_',' ').title());plt.tight_layout();plt.savefig(out/f'{name}.png',dpi=160);plt.close()
    models['data_audit']=audit
    models['analysis_source']='EXPLICITLY_SYNTHETIC_DEMONSTRATION_DATA' if demo else 'USER_SUPPLIED_OR_EXTERNAL_CSV_VERIFY_PROVENANCE'
    (out/'analysis_results.json').write_text(json.dumps(models,indent=2,default=str),encoding='utf-8')
    export_dashboard(df,out/'dashboard.html',f'SYNTHETIC DEMONSTRATION ONLY ({source.name})' if demo else f'CSV: {source.name} | SHA256 {audit["sha256"][:12]}')
    print(json.dumps({'mode':'SYNTHETIC DEMO' if demo else 'SOURCE CSV','rows':len(df),
              'sales':audit['sales_total'],'profit':audit['profit_total'],
              'model_statuses':{k:v['status'] for k,v in models.items() if isinstance(v,dict) and 'status' in v},
              'output':str(out)},indent=2))
    return models

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--input',type=Path,help='Actual Superstore CSV path')
    group.add_argument('--demo',action='store_true',help='Run synthetic demonstration fixture only')
    parser.add_argument('--output-dir',type=Path,default=Path('outputs/real'))
    args=parser.parse_args()
    path=args.input
    if args.demo:path=generate_demo(Path('data/Superstore_demo_fixture.csv'))
    run(path,args.output_dir,demo=args.demo)
