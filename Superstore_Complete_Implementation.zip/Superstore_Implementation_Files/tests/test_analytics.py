import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from src.demo_fixture import generate_demo
from src.analytics import read_clean,aggregate,monthly_summary,customer_segmentation,row_sales_regression,forecasting_backtest

class TestAnalytics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.csv=generate_demo(Path(cls.tmp.name)/'fixture.csv',n=720)
        cls.df,cls.audit=read_clean(cls.csv)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_clean_preserves_lines(self):
        self.assertEqual(len(self.df),720)
        self.assertEqual(self.audit['dropped_rows'],0)
    def test_losses_preserved(self):
        self.assertGreater(self.audit['negative_profit_lines'],0)
        self.assertEqual(self.audit['negative_profit_lines'],self.audit['retained_negative_profit_lines'])
    def test_order_distinct_from_lines(self):
        self.assertLess(self.df['Order ID'].nunique(),len(self.df))
    def test_region_reconciliation(self):
        r=aggregate(self.df,'Region')
        self.assertAlmostEqual(r['sales'].sum(),self.df['Sales'].sum(),places=5)
        self.assertAlmostEqual(r['profit'].sum(),self.df['Profit'].sum(),places=5)
    def test_month_reconciliation(self):
        r=monthly_summary(self.df)
        self.assertAlmostEqual(r['sales'].sum(),self.df['Sales'].sum(),places=5)
    def test_customer_cluster_deterministic(self):
        a,meta=customer_segmentation(self.df)
        b,other=customer_segmentation(self.df)
        self.assertEqual(meta['status'],'completed')
        self.assertTrue(a['cluster'].equals(b['cluster']))
    def test_regression_split_and_no_profit_leakage(self):
        r=row_sales_regression(self.df)
        self.assertEqual(r['status'],'completed')
        self.assertNotIn('Profit',r['features'])
        self.assertGreater(r['test_rows'],0)
    def test_forecasting_backtest(self):
        r=forecasting_backtest(monthly_summary(self.df))
        self.assertEqual(r['status'],'completed')
        self.assertGreater(r['backtest_months'],0)
    def test_negative_discount_rejected(self):
        x=pd.read_csv(self.csv);x.loc[0,'Discount']=-.1
        tmp=Path(self.tmp.name)/'bad.csv';x.to_csv(tmp,index=False)
        with self.assertRaisesRegex(ValueError,'Discount'):read_clean(tmp)
    def test_missing_required_column_rejected(self):
        x=pd.read_csv(self.csv).drop(columns=['Profit']);tmp=Path(self.tmp.name)/'missing.csv';x.to_csv(tmp,index=False)
        with self.assertRaisesRegex(ValueError,'Missing required'):read_clean(tmp)
    def test_duplicate_row_key_rejected(self):
        x=pd.read_csv(self.csv);x.loc[1,'Row ID']=x.loc[0,'Row ID'];tmp=Path(self.tmp.name)/'dupe.csv';x.to_csv(tmp,index=False)
        with self.assertRaisesRegex(ValueError,'Row ID'):read_clean(tmp)
    def test_ship_precedes_order_rejected(self):
        x=pd.read_csv(self.csv);x.loc[0,'Ship Date']='01/01/2013';tmp=Path(self.tmp.name)/'early.csv';x.to_csv(tmp,index=False)
        with self.assertRaisesRegex(ValueError,'Ship Date'):read_clean(tmp)

if __name__=='__main__':unittest.main()
