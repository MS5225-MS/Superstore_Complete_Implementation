# Dashboard deployment and evaluation guide

## Status and interpretation

The working dashboard in the project bundle is a **standalone HTML application**. It is not a tested native `.pbix`, `.twb` or `.twbx` project. The bundled fixture is **synthetic demonstration data**, not actual retailer transactions. Tableau characterises Superstore as a fictitious retailer example: https://help.tableau.com/current/guides/get-started-tutorial/en-us/get-started-tutorial-connect.htm

## Replace the demonstration data

1. Obtain a documented public copy of Tableau's **Sample – Superstore** orders data or the actual CSV supplied by the student/supervisor.
2. Preserve the original untouched. Record the filename, URL, retrieval date, exact row count, and SHA-256 checksum.
3. Ensure fields include: Row ID, Order ID, Order Date, Ship Date, Customer ID, Segment, Region, Category, Sub-Category, Sales, Quantity, Discount, Profit.
4. Run `python run_analysis.py --input data/<filename>.csv --output-dir outputs/public_sample` from the project directory. The parser expects M/D/YYYY date strings; convert date formatting explicitly if the file uses another date format.
5. Compare reported row and order counts with the raw file. Inspect negative-profit records, outliers, missing fields and any data errors. Preserve negative profit.
6. Run `python -m unittest discover -s tests -v`, then manually inspect the dashboard and update the MSc report with exact outputs from `outputs/public_sample/analysis_results.json`.
7. Do not reuse demonstration figures or test scores as the public dataset results.

## Create a native Power BI dashboard

1. In Power BI Desktop, Get Data → Text/CSV → import `outputs/public_sample/cleaned_superstore_internal.csv`.
2. Set Order Date/Ship Date as dates; Sales, Profit, Quantity and Discount as numeric; Order ID and Row ID as text/whole number as appropriate.
3. Create measures (DAX examples):

   `Total Sales = SUM('Superstore'[Sales])`

   `Total Profit = SUM('Superstore'[Profit])`

   `Profit Margin = DIVIDE([Total Profit], [Total Sales], 0)`

   `Orders = DISTINCTCOUNT('Superstore'[Order ID])`

4. Create KPI cards for the four measures; line chart Order Month × Total Sales; column charts Region × Total Profit and Category × Total Profit; slicers for Year, Region, Category and Segment.
5. Cross-check every total against `analysis_results.json` from the **same imported source**. Test filters and exclusion of personally identifying fields. Only then save as a `.pbix` file.

## Create a native Tableau dashboard

1. In Tableau Desktop, connect to the cleaned CSV (Text File); use Date type for Order Date.
2. Build calculated field `Profit Margin = SUM([Profit]) / SUM([Sales])`.
3. Make trend (MONTH Order Date vs SUM Sales), region and category profit bars, and KPI sheets.
4. Combine views on a dashboard; add region, segment, year and category filters with Apply to Worksheets → All Using This Data Source.
5. Compare Tableau/Power BI totals against the Python outputs; save as `.twbx` or `.twb` with verified data connections.

## Methodological cautions

- Do not confuse *line items* with *orders*; use DISTINCTCOUNT for Order ID.
- Discount correlations do not establish cause-and-effect.
- Forecasting must use out-of-time evaluation, not random split.
- RFM clusters and ML scores change when source CSV or split changes; rerun all analyses on the final CSV.
- No evidence of actual human user testing or university ethical approval has been provided; do not claim either.
